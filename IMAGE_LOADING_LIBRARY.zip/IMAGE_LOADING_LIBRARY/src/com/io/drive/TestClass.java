package com.io.drive;

import java.util.Scanner;

public class TestClass {
	public static void main(String[] args) throws Throwable, Throwable {
		Scanner sc= new Scanner(System.in); //System.in is a standard input stream 
		System.out.println("format should start with https://");
		System.out.println("Enter page url eg :"
				+ "https://www.pikwizard.com/n"+
				"https://www.unsplash.com/n"+
				"https://www.pixabay.com");  
		String page_url= sc.nextLine();              //reads string   
		System.out.print("You have entered: "+page_url);         
		//String page_url="https://www.pikwizard.com/";
	    // String page_url= "https://pixabay.com/images/search/wall/";
	    	 // String page_url="https://unsplash.com";
		start_application app=new start_application(page_url);
		app.StartApplication();
		
	}
}
