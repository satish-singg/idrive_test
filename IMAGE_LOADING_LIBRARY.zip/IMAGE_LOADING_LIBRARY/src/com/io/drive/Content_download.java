package com.io.drive;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL ;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
//import java.io.OutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
public class Content_download extends Thread{
	private static final int BUFFER_SIZE = 4096;
	ArrayList<String> urlStore;
	static String address;
	static Lrucaching cache;
	public Content_download(ArrayList<String> urlStore, Lrucaching cache)  {
		 this.urlStore=urlStore;
		 Content_download.cache=cache;
		}
	public static void downloadFile(String fileURL, Lrucaching cache)
            throws IOException, Throwable {
        URL url = new URL(fileURL);
        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
        int responseCode = httpConn.getResponseCode();
 
        // always check HTTP response code first
        if (responseCode == HttpURLConnection.HTTP_OK) {
            String fileName = "";
            String disposition = httpConn.getHeaderField("Content-Disposition");
            String contentType = httpConn.getContentType();
            int contentLength = httpConn.getContentLength();
 
            if (disposition != null) {
                // extracts file name from header field
                int index = disposition.indexOf("filename=");
                if (index > 0) {
                    fileName = disposition.substring(index + 10,
                            disposition.length() - 1);
                }
            } else {
                // extracts file name from URL
               // fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1,
                //        fileURL.length());
                fileName=Paths.get(new URI(fileURL).getPath()).getFileName().toString();
            }
 
            System.out.println("Content-Type = " + contentType);
            System.out.println("Content-Disposition = " + disposition);
            System.out.println("Content-Length = " + contentLength);
            System.out.println("fileName = " + fileName);
            System.out.println("url= " + fileURL);

            if(cache.get(fileName)!=null) {
            	try {
            	FileInputStream is=new FileInputStream("CacheStorage/" +File.separator +fileName);
      		  FileOutputStream fo=new FileOutputStream("StorageFile/" +File.separator +fileName);
      		  
      		  int b=0;
      		  while((b=is.read())!=-1) {
      			  //write into output stream
      			  fo.write(b);
      		  }
      			System.out.println("NOT DOWNLOADED bt COPIED FROM CACHE to STORAGE");

      		  fo.close();
      		  is.close();}
      		catch(Exception e) {
      			System.out.println(e.getMessage());
      		}
      	  }
            // opens input stream from the HTTP connection
            else {
            InputStream inputStream = httpConn.getInputStream();
            String StorageFilePath = "StorageFile/" + File.separator + fileName;
            String CacheFilePath = "CacheStorage/" + File.separator + fileName;
 
            // opens an output stream to save into file
            FileOutputStream StorageoutputStream = new FileOutputStream(StorageFilePath);
            FileOutputStream CacheoutputStream = new FileOutputStream(CacheFilePath);

            int bytesRead = -1;
            byte[] buffer = new byte[BUFFER_SIZE];
            while ((bytesRead = inputStream.read(buffer)) != -1) {
            	StorageoutputStream.write(buffer, 0, bytesRead);
            	CacheoutputStream.write(buffer, 0, bytesRead);

            }
            System.out.println("downloading from server");
            StorageoutputStream.close();
            CacheoutputStream.close();
            inputStream.close();
           // delete the head file from cache storage area
            String pathdelete=cache.put(fileName,CacheFilePath);
            
            if(pathdelete!=null)                      //returns Boolean value  
            {  File f=new File(pathdelete);
            	f.delete();
            System.out.println(f.getName() + "file  deleted from cache memory");   //getting and printing the file name  
            }  
            System.out.println("File downloaded");
        } 
            }
        else {
            System.out.println("No file to download. Server replied HTTP code: " + responseCode);
        }
        httpConn.disconnect();
    }

	public void check() {
		for(String address:urlStore) {
		//if(cache.get(address)!=null) {
		//	System.out.println("file already exist in cache memory");
			//content_download_retrieve.copy_inside_storage(address);
			//Content_download.copy_inside_storage(address);
		//}
		//else {
			//cache.put(address,address);
			
			try {
				//Content_download.downloadFile(address,"CacheStorage/");
				//Content_download.downloadFile(address,"StorageFile/");
				Content_download.downloadFile(address,cache);

				} 
			catch (Throwable ex) {
	            ex.printStackTrace();
	        }
		//}
	}
		}

}
