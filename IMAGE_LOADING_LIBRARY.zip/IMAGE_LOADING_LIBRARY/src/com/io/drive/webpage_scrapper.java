package com.io.drive;

import java.util.ArrayList;
import java.util.Optional;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v93.network.Network;
import org.openqa.selenium.devtools.v93.network.model.Response;
import org.openqa.selenium.devtools.v93.network.model.Request;



public class webpage_scrapper extends Thread{

	public   ArrayList<String> DigPageForLink(String PageUrl) {
		

        String url =PageUrl;
         ArrayList<String> urlStore= new ArrayList<String>();  
         //I will chrome driver developer tool to inspect webpage
         System.setProperty("webdriver.chrome.driver","C:\\Program Files\\chromedriver\\chromedriver.exe");
         System.setProperty("webdriver.chrome.whitelistedIps", "");
         ChromeDriver driver = new ChromeDriver();
         //javascript executor will be ued to inject required javascript into webpage
         JavascriptExecutor jse = (JavascriptExecutor)driver;
         DevTools devTools=driver.getDevTools();
         devTools.createSession();
         devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
         devTools.addListener(Network.requestWillBeSent(),
                 request -> {
                	 Request req= request.getRequest();
                	 
                     System.out.println("URL - " + req.getUrl());
                 });
         devTools.addListener(Network.responseReceived(),
                 response -> {
                     Response res= response.getResponse();
                     urlStore.add(res.getUrl());
                   
                 });
         	driver.get(url);
         	
			//I will inject js query into chrome devtool webpage for auto scrolling purpose
			jse.executeScript("setInterval(function(){window.scrollBy(0,2);},10)");
			try {
				Thread.sleep(160000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			return urlStore;
			
	}
}