package com.io.drive;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class start_application {
	  String PageUrl;//="https://www.pikwizard.com/";
	     // String PageUrl= "https://pixabay.com/images/search/wall/";
	    	 // String PageUrl="https://unsplash.com";
	public start_application(String PageUrl) {
		this.PageUrl=PageUrl;
	}
	public  void StartApplication() throws Throwable, Throwable {
	
     
      
    	ArrayList<String> urlStore=null;
    	webpage_scrapper webpage=new webpage_scrapper();
        urlStore=webpage.DigPageForLink(PageUrl);
    	// file to save state of cache object
		File CacheObjectFile=new File("cache.txt");
        Lrucaching cache=null;
        if (!CacheObjectFile.exists()) {
        	//create a new cache object if not exist with limited space

        	 CacheObjectFile = new File("cache.txt");
        	 cache =new Lrucaching(250);
        }
        else {
        	//retrieve the saved states of cache object by reading Cache text file
		    FileInputStream fis = new FileInputStream(CacheObjectFile);
		    ObjectInputStream ois = new ObjectInputStream(fis);
		    cache = (Lrucaching) ois.readObject();
		    ois.close();
        }
		
		//image will be either downloaded and cache object state will change
	    Content_download downloader_object=new Content_download(urlStore,cache);
	    downloader_object.fetch_process_start();
        //Construct the LineNumberReader object
		
	    FileOutputStream fos = new FileOutputStream(CacheObjectFile);
	    ObjectOutputStream oos = new ObjectOutputStream(fos);
	    oos.writeObject(cache);
	    oos.close();

	}

}
