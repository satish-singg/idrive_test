package com.io.drive;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;

public class start_application {

	public static void main(String[] args) throws Throwable, Throwable {
		// TODO Auto-generated method stub
		String filePath = "cache.txt";
        File file = new File(filePath);
        String PageUrl="https://www.pikwizard.com/";
    	ArrayList<String> urlStore=null;

        urlStore=webpage_scrapper.DigPageForLink(PageUrl);
        Lrucaching cache=null;
        if (!file.exists()) {
        	//limited space for caching purpose
        	 cache =new Lrucaching(250);
        }
        else {
        	//retrieve the saved states of cache object
		    FileInputStream fis = new FileInputStream(file);
		    ObjectInputStream ois = new ObjectInputStream(fis);
		    cache = (Lrucaching) ois.readObject();
		    ois.close();
        }
		
		//image will be downloaded and cache object state will change
	    Content_download cdr=new Content_download(urlStore,cache);
		cdr.check();
        
		//saving the state of cache object into text file for further use
	    FileOutputStream fos = new FileOutputStream(file);
	    ObjectOutputStream oos = new ObjectOutputStream(fos);
	    oos.writeObject(cache);
	    oos.close();

	}

}
